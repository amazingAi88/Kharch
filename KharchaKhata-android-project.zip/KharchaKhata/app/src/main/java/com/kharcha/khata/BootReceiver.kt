package com.kharcha.khata

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** फोन रीस्टार्ट होने के बाद रिमाइंडर दोबारा चालू करता है। */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Reminder.schedule(ctx)
    }
}
